/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package portugol.arvoresintatica;

/**
 *
 * @author Kennedy
 */
public class NoSintatico {

    private int numeroLinha;

    public NoSintatico(int numeroLinha){
        this.numeroLinha = numeroLinha;
    }

    public int obterNumeroLinha(){
        return numeroLinha;
    }
}
