/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package portugol.arvoresintatica;

/**
 *
 * @author Kennedy
 */
public enum NomeComando {
    LER,
    ESCREVER,
    ATRIBUICAO,
    CONDICAO,
    LACO_ENQUANTO,
    LACO_DE_ATE,
    BLOCO_COMANDOS
}
