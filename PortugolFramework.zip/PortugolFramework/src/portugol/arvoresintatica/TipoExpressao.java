/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package portugol.arvoresintatica;

/**
 *
 * @author Kennedy
 */
public enum TipoExpressao {
    NUMERO_INTEIRO,
    NUMERO_REAL,
    CADEIA_CARACTERES,
    IDENTIFICADOR,
    EXPRESSAO_ARITMETICA,
    EXPRESSAO_RELACIONAL

}
