/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package portugol.lexico;

/**
 *
 * @author ckenn
 */
public class Assembly {
    public static final String EAX = "eax";
    public static final String MOV = "mov";
    public static final String ADD = "add";
    public static final String SUB = "sub";
    public static final String MUL = "mul";
    public static final String DIV = "div";
    
}
